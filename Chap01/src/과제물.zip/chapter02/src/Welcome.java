import java.util.Scanner;
public class Welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		System.out.print("당신의 이름을 입력하세요: ");
		String name = scan.next();
		System.out.print("연락처를 입력하세요: ");
		String number = scan.next();
		System.out.println("***********************************************");
		
		System.out.println("\tWelcome to Shopping Mall");
		System.out.println("\tWelcome to Book Market");
		System.out.println("***********************************************");
		
		System.out.printf("%-60s%n", " 1. 고객 정보 확인하기	4. 바구니에 항목 추가하기");
		System.out.printf("%-60s%n", " 2. 장바구니 상품 목록 보기	5. 장바구니의 항목 수량 줄이기");  
		System.out.printf("%-60s%n", " 4. 장바구니 비우기		6. 장바구니의 항목 삭제하기"); 
		System.out.printf("%-60s%n", " 7. 영수증 표시하기		8. 종료");  
		
		System.out.println("***********************************************");

		System.out.print("메뉴 번호를 선택해주세요 ");
		int choice = scan.nextInt();
		System.out.printf("%d번을 선택했습니다", choice);
	}

}
